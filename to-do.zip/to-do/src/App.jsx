import Todo from "./components/Todo";

function App() {
  return (
    <div className='main main-bg'>
      <Todo />
    </div>
  );
}

export default App;
