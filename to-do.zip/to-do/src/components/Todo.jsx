import React, { useState } from "react";
import TodoForm from "./TodoForm";
import DateTime from "./DateTime";
import TodoList from "./TodoList";
import ClearTodoList from "./ClearTodoList";
import TodoTitle from "./TodoTitle";
import { getLocalStorageTodoData, sssetLocalStorageTodoData } from './TodoLocalStorage';

const Todo = () => {
  const [list, setList] = useState(() => getLocalStorageTodoData());
  const handleDelete = (value) => {
    const updatedList = list.filter(
      (currentTask) => currentTask.content !== value
    );
    setList(updatedList);
  };

  const handleFormSubmit = (inputValue) => {
    const { id, content, checked } = inputValue;
    if (!content) return;

    const isMatched = list.some((value) => value.content === content);
    if (isMatched) return;

    setList((prevTask) => [...prevTask, { id, content, checked }]);
  };

  sssetLocalStorageTodoData(list)

  const handleClear = () => {
    setList([]);
  };

  const handleCheckedToto = (value) => {
    const updatedValue = list.map((currValue) => {
      if (currValue.content === value) {
        return { ...currValue, checked: !currValue.checked };
      } else {
        return currValue;
      }
    });
    setList(updatedValue);
  };

  return (
    <div>
      <section>
        <header className='text-center headings'>
          <TodoTitle />
          <DateTime />
        </header>

        <TodoForm onAddTodo={handleFormSubmit} />

        <ul className='list-style list-style-none mt-5'>
          {list.map((value) => (
            <TodoList
              key={value.id}
              data={value.content}
              checked={value.checked}
              handleDelete={handleDelete}
              onHandleCheckedToto={handleCheckedToto}
            />
          ))}
        </ul>
      
      <div className='place-center'>
        <ClearTodoList handleClear={handleClear} />
        </div>
      </section>
    </div>
  );
};

export default Todo;
