import React, { useState } from "react";

const TodoForm = ({ onAddTodo }) => {
  const [inputValue, setInputValue] = useState({});

  const handleInputChange = (value) => {
    setInputValue({ id: value, content: value, checked: false });
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    onAddTodo(inputValue);
    setInputValue({ id: "", content: "", checked: false });
  };

  const handleClearInputValue = () => {
    setInputValue("");
  };

  return (
    <section>
      <form className="form" onSubmit={handleFormSubmit}>
        <div className="self-center" style={{ position: "relative" }}>
          <input
            className="input"
            placeholder="Enter the items.."
            type="text"
            autoComplete="off"
            value={inputValue.content}
            onChange={(event) => handleInputChange(event.target.value)}
          />
          <button onClick={() => handleClearInputValue()} className="close-btn">
            X
          </button>
        </div>
        <div className="self-center">
          <button className="btn" type="submit">
            Add Task
          </button>
        </div>
      </form>
    </section>
  );
};

export default TodoForm;
