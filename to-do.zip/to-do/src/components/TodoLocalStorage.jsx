const todosKey = "todo";

export const getLocalStorageTodoData = () => {
  const rowTodos = localStorage.getItem(todosKey);
  if (!rowTodos) return [];
  return JSON.parse(rowTodos);
};

export const sssetLocalStorageTodoData = (list) => {
  return localStorage.setItem(todosKey, JSON.stringify(list));
};
