import React from "react";

const ClearTodoList = ({handleClear}) => {
  return <button className='btn' onClick={handleClear}>Clear All</button>;
};

export default ClearTodoList;
