import React from "react";
import { MdCheck, MdDeleteForever } from "react-icons/md";

const TodoList = ({ data, checked, handleDelete, onHandleCheckedToto }) => {
  return (
    <li className="items-list">
    <div className='items-flex'>
      <div>
        <span className={`${checked ? "checkList" : "notCheckList"} list-items`}>{data}</span>
      </div>
      <div>
        <button className='small-check-btn mx-5' onClick={() => onHandleCheckedToto(data)}>
          <MdCheck />
        </button>
        <button className='small-delete-btn' onClick={() => handleDelete(data)}>
          <MdDeleteForever />
        </button>
      </div>
      </div>
    </li>
  );
};

export default TodoList;
