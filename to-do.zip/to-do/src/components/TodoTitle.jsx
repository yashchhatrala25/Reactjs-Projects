import React from 'react'

const TodoTitle = () => {
  return (
    <h1 className='heading-1'>Todo List</h1>
  )
}

export default TodoTitle
